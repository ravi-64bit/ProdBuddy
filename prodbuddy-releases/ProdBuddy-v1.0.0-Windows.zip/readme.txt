ProdBuddy

An opensource option to keep track of your tasks, no matter what work you do.

Features:
Views: Switch between Today (due and overdue unfinished tasks), All tasks, or individual Projects, with a Project column and project selector dropdown when adding from multi-project views.
Subtasks & Tags: Create subtasks under tasks and organize items with comma-separated tags (work, urgent, #home) and multi-line task notes.
Live Timer: Start and stop a per-task timer with live elapsed seconds in the status bar and Tracked column, plus visual highlight on the active task.
Light & Dark Themes: Toggle between light and dark palettes with custom themed dialogs and automatic logo switching.
Safe Storage & Transfer: SQLite database in Documents\ProdBuddy\tracker.db with automatic daily backups (keeping the 7 newest) and JSON export/import.


If Windows' SmartScreen shows 'Windows protected your PC' because some antivirus tools flag PyInstaller apps, please click more info and click Run Anyway. This issue will be handled soon.


Contact the developer at ravi004k@myyahoo.com
